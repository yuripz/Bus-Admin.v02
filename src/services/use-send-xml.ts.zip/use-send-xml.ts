import Axios from 'axios';
import { useQuery } from 'react-query';

export type Method = 'post' | 'get' | 'patch' | 'put';
export type Url = string;

const headers = {
  'Content-type': 'text/xml',
};

export const useSendXml = <T>(
  key: string,
  method: Method,
  url: Url,
  request?: any,
  deps?: any[],
  fetchManual?: boolean,
// eslint-disable-next-line max-params
) => {

  const queryResult = useQuery(
    [key, deps],
    () =>
      Axios[method](`${process.env.REACT_APP_BASEURL}${url}`, request, {
        headers: headers,
      }),
    {
      enabled: !fetchManual,
      staleTime: 100_000_000,
    }
  );

  const { isLoading, error, data, refetch, isFetching } = queryResult;

  let res;

  if (!isLoading && data?.data) {
    res = data.data;
  }

  return { isLoading, error, res, refetch, isFetching };
};
